module.exports = {
    arrowParens: "always",
    bracketSpacing: true,
    bracketSameLine: false,
    endOfLine: "lf",
    printWidth: 100,
    semi: true,
    singleQuote: false,
    tabWidth: 4,
    trailingComma: "es5",
    useTabs: false,
};
